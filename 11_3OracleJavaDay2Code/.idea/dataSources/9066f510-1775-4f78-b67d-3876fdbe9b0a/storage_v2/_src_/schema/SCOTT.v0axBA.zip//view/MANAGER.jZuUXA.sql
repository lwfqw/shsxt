create view MANAGER as
(select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO" from emp where empno in(select distinct mgr from emp))
/

